import matplotlib.pyplot as plt
import json
import requests
sh='2023-03-01'
ed='2023-03-22'
url = f'https://ik-roster.cisco.com/roster/plotGraphRoster/?start_date={sh}&end_date={ed}&wg=APT-AMP'

request = requests.get(url)
eng = []
data = request.json()
print(data)
eng=[]
print(len(data))

# uni_eng = set(eng)
# uni_eng=list(uni_eng)
# print(uni_eng)