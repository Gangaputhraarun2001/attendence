from django.http import HttpResponse,JsonResponse
from django.shortcuts import render
import json,requests
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from datetime import datetime
import os

def index(request):
    return render(request,'base.html')

def analyze(request):
    # get the text
    djtext=request.GET.get('start_date','default')
    sh=request.GET.get('end_date','default')
    work=request.GET.get('wg','default')
    work=str(work)
    djtext=str(djtext)
    sh=str(sh)
    url = f'https://ik-roster.cisco.com/roster/plotGraphRoster/?start_date={djtext}&end_date={sh}&wg={work}'

    eng = []
    dates = []
    req=requests.get(url)
    response = req.json()
    for i in response:
        eng.append(i['engineer'])
        dates.append(i['r_date'])
        print(i)

    uni_eng = set(eng)
    x = sorted(set(dates))

    #print(uni_eng)
    #print(x)

    data ={}
    for j in x:
        data[j] = []

    for item in response:
        for a in x:
            if item['r_date'] == a and item['attendance'] != 'OffQueue' and item['attendance'] != 'weekend':
                data[a].append(item['engineer'])
    data1 ={}
    for j in uni_eng:
        data1[j] = []

    for item in response:
        for b in uni_eng:
            if item['engineer'] == b and item['attendance'] != 'OffQueue' and item['attendance'] != 'weekend':
                date_string = item['r_date']
                date = datetime.strptime(date_string, '%Y-%m-%d')
                o = date.strftime('%B')
                data1[b].append(o)




    months = []
    for e,d in data.items():
        #print(e, d)
        date_string = e
        date = datetime.strptime(date_string, '%Y-%m-%d')
        months.append(date.strftime('%B'))

    month_list = list(set(months))
    #for l in data1:
    #    for u in month_list:
    #        print(l, u, data1[l].count(u))

    actual_data = {}
    for j in uni_eng:
        actual_data[j] = {}

    for l in data1:
        for u in month_list:
            actual_data[l][u] = data1[l].count(u)
            #print(l, u, data1[l].count(u))
    #print(month_list)
    #print(actual_data)


    mylist = []
    for p, v in actual_data.items():
        mydict = {"label": p, "values": []}
        for u in month_list:
            mydict['values'].append(v[u])
        mylist.append(mydict)

    #print(mylist)

    json_data = {"labels": month_list,

                 "data": mylist }

    print(json_data)
  

    json_file = os.path.join(os.path.dirname(__file__), 'static/data/graph.json')



    with open(json_file, "w") as outfile:
        json.dump(json_data, outfile, indent=4)
    context= {"con": json_data} 
    #return render(request,'analyze.html',context)
    return JsonResponse(json_data)

def analyze1(request):
    djtext=request.GET.get('start_date','default')
    sh=request.GET.get('end_date','default')
    work=request.GET.get('wg','default')
    work=str(work)
    djtext=str(djtext)
    sh=str(sh)
    context={'st':djtext,'ed':sh,'wk':work}
    return render(request,'analyze.html',context)